//Servidor de:
//Araujo, Juan Ignacio 10649
//Silva, Victor        10988

#include "include/Calculadora.hpp"
#include "lib/XmlRpc.h"
#include <cmath>
using namespace XmlRpc;

XmlRpcServer s;

// Puerto a usar
const int PORT = 8080;

int main(int argc, char* argv[]) {

  Calculadora calc(&s);

  // Crea el socket del servidor en el puerto especificado 
  s.bindAndListen(PORT);

  // Espera por solicitudes y sigue procesando indefinidamente  
  s.work(-1.0);
  
  //(Ctrl-C para cancelar)
  return 0;
}