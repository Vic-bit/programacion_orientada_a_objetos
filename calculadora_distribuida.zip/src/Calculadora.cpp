#include "../include/Calculadora.hpp"

Calculadora::Calculadora(XmlRpcServer *s) {
    obsum = new Suma(s, historial);
    obres = new Resta(s, historial);
    obmul = new Multiplicacion(s, historial);
    obdiv = new Division(s, historial);
    obpot = new Potenciacion(s, historial);
    obrad = new Radicacion(s, historial);
    obhist = new Historia(s, historial);
}

Calculadora::~Calculadora() {
    delete obsum;
    delete obres;
    delete obmul;
    delete obdiv;
    delete obpot;
    delete obrad;
    delete obhist;

}

