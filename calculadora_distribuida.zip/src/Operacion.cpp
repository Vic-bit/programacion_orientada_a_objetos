#include "../include/Operacion.hpp"

Operacion::Operacion(double op1, double op2, std::string operad) {
this-> operando_1 = op1;
this-> operando_2 = op2;
this-> operador = operad;
}

Operacion::~Operacion() {}

std::string Operacion::toString() const{
    return (std:: to_string(operando_1) + "" + operador + "" + std::to_string(operando_2));
}

