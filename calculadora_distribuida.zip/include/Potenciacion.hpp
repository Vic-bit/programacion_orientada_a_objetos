#pragma once
#include <cmath>
#include "Operacion.hpp"
#include "../lib/XmlRpc.h"

using namespace XmlRpc;

class Potenciacion : public XmlRpcServerMethod {
private:
  std::list<Operacion> *listadeoperac;

public:
  Potenciacion(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obpot", s) {
    this->listadeoperac = &listadeoperac;
  }

  void execute(XmlRpcValue &params, XmlRpcValue &result) {
    result = std::pow(double(params[0]), double(params[1]));
    listadeoperac->insert(listadeoperac->end(),
        Operacion(double(params[0]), double(params[1]), "^"));
  }
};