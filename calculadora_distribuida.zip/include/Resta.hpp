#pragma once
#include <cmath>
#include "Operacion.hpp"
#include "../lib/XmlRpc.h"


using namespace XmlRpc;

class Resta : public XmlRpcServerMethod {
private:
  std::list<Operacion> *listadeoperac;

public:
  Resta(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obres", s) {
    this->listadeoperac = &listadeoperac;
  }

  void execute(XmlRpcValue &params, XmlRpcValue &result) {
    result = double(params[0]) - double(params[1]);
    listadeoperac->insert(listadeoperac->end(),
        Operacion(double(params[0]), double(params[1]), "-"));
  }
};