#pragma once
#include <cmath>
#include "Operacion.hpp"
#include "../lib/XmlRpc.h"

#include "Division.hpp"
#include "Multiplicacion.hpp"
#include "Radicacion.hpp"
#include "Potenciacion.hpp"
#include "Resta.hpp"
#include "Suma.hpp"
#include "Historia.hpp"

using namespace XmlRpc;

class Calculadora {
private:
    Division *obdiv;
    Multiplicacion *obmul;
    Radicacion *obrad;
    Potenciacion *obpot;
    Resta *obres;
    Suma *obsum;
    Historia *obhist;
    std::list<Operacion> historial;
public:
    Calculadora(XmlRpcServer *s);
    ~Calculadora();
    /*double divis();
    double multipl();
    double potencia();
    double raiz();
    double restando();
    double sumando();
    */

};