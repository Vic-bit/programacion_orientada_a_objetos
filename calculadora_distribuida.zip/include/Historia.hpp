#pragma once
#include <cmath>
#include "../lib/XmlRpc.h"
#include "Operacion.hpp"


using namespace XmlRpc;

class Historia : public XmlRpcServerMethod {
private:
    std::list<Operacion> *listadeoperac;

public:
    Historia(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obhist", s) {
        this->listadeoperac = &listadeoperac;
    }

    void execute(XmlRpcValue &params, XmlRpcValue &result) {
        std::string buffer = "Historial de Operaciones:\n";
        for (auto const &i : *listadeoperac) {
        buffer += i.toString() + "\n";
        }
        result = buffer;
    }
};