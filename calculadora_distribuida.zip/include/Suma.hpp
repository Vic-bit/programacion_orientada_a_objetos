#pragma once
#include <cmath>
#include "../lib/XmlRpc.h"
#include "Operacion.hpp"

using namespace XmlRpc;

class Suma : public XmlRpcServerMethod {
private:
  std::list<Operacion> *listadeoperac;

public:
  Suma(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obsum", s) {
    this->listadeoperac = &listadeoperac;
  }

  void execute(XmlRpcValue &params, XmlRpcValue &result) {
    result = double(params[0]) + double(params[1]);
    listadeoperac->insert(listadeoperac->end(),
        Operacion(double(params[0]), double(params[1]), "+"));
  }
};