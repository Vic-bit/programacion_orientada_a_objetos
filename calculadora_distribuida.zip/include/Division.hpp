#pragma once
#include <cmath>
#include "../lib/XmlRpc.h"
#include "Operacion.hpp"


using namespace XmlRpc;

class Division : public XmlRpcServerMethod {
private:
  std::list<Operacion> *listadeoperac;

public:
  Division(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obdiv", s) {
    this->listadeoperac = &listadeoperac;
  }

  void execute(XmlRpcValue &params, XmlRpcValue &result) {
    try {
      result = double(params[0]) / double(params[1]);
    } catch (...) {
      result = 0.0;
    }
    listadeoperac->insert(
      listadeoperac->end(),Operacion(double(params[0]), double(params[1]), "/"));
  }
  //////////////
};