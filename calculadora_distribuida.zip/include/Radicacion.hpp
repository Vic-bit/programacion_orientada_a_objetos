#pragma once
#include <cmath>
#include "../lib/XmlRpc.h"
#include "Operacion.hpp"

using namespace XmlRpc;

class Radicacion : public XmlRpcServerMethod {
private:
  std::list<Operacion> *listadeoperac;

public:
  Radicacion(XmlRpcServer *s, std::list<Operacion> &listadeoperac):XmlRpcServerMethod("obrad", s) {
    this->listadeoperac = &listadeoperac;
  }

  void execute(XmlRpcValue &params, XmlRpcValue &result) {
    result = std::pow(double(params[0]), 1 / double(params[1]));
    listadeoperac->insert(listadeoperac->end(),
        Operacion(double(params[0]), double(params[1]), "^1/"));
  }
};