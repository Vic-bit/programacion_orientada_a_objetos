#pragma once
#include <iostream>
#include <string>

class Operacion {
private:
    double operando_1;
    double operando_2;
    std::string operador;

public:
    Operacion(double op1, double op2, std::string operad);
    ~Operacion();
    std::string toString() const;
};