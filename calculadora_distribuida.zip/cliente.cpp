//Cliente de:
//Araujo, Juan Ignacio 10649
//Silva, Victor        10988

#include "lib/XmlRpc.h"
#include <iostream>

using namespace XmlRpc;

int main(int argc, char *argv[]) {

  if (argc != 3) {
    //"c error"
    std::cerr << "Usage: HelloClient serverHost serverPort\n";
    return -1;
  }

  const char *hostname = argv[1];
  int port = atoi(argv[2]);
  double num1, num2;
  
  while (true) {
    char opcion;

    std::cout << "=========================================" << std::endl
              << "CALCULADORA DISTRIBUIDA CON RPC" << std::endl
              << "=========================================" << std::endl;
    std::cout << "a. Adicion" << std::endl
              << "s. Sustraccion" << std::endl
              << "m. Multiplicacion" << std::endl
              << "d. Division" << std::endl
              << "p. Potenciacion" << std::endl
              << "r. Radicacion" << std::endl
              << "h. Historial" << std::endl
              << "t. Terminar" << std::endl
              << "*****************************************" << std::endl;
    std::cout << "Elija una opcion: ";
    std::cin >> opcion;

    switch (opcion) {
        case 't':
            std::cout << "Servicio terminado" << std::endl;
            return 0;
            break;
        case 'h':
            break;
        case 'a':
            std::cout << "Primer sumando: ";
            std::cin >> num1;
            std::cout << "Segundo sumando: ";
            std::cin >> num2;
            break;
        case 's':
            std::cout << "Minuendo: ";
            std::cin >> num1;
            std::cout << "Sustraendo: ";
            std::cin >> num2;
            break;
        case 'm':
            std::cout << "Operando 1: ";
            std::cin >> num1;
            std::cout << "Operando 2: ";
            std::cin >> num2;
            break;
        case 'd':
            std::cout << "Numerador: ";
            std::cin >> num1;
            std::cout << "Denominador: ";
            std::cin >> num2;
            break;
        case 'p':
            std::cout << "Base: ";
            std::cin >> num1;
            std::cout << "Exponente: ";
            std::cin >> num2;
            break;
        case 'r':
            std::cout << "Radicando: ";
            std::cin >> num1;
            std::cout << "Indice: ";
            std::cin >> num2;
            break;
        default:
            std::cout << "No se seleccionó ninguna operación válida." << std::endl;
    }
    
    //excepcion de la division:
    if (opcion == 'd' && num2 == 0) {
      std::cout << "ERROR: No se puede dividir por cero!" << std::endl;
      continue;
    }

    //Creacion cliente y coneccion al servidor
    XmlRpcClient client(hostname, port);
    XmlRpcValue noArgs, emptyArgs, result;

    noArgs[0] = num1;
    noArgs[1] = num2;

    if (opcion == 'a' || opcion == 's' || opcion == 'm' || opcion == 'd' || opcion == 'p' || opcion == 'r' || opcion == 'h') {
      if (opcion == 'a'){
        client.execute("obsum", noArgs, result);
      }
      if (opcion == 's'){
        client.execute("obres", noArgs, result);
      }
      if (opcion == 'm'){
        client.execute("obmul", noArgs, result);
      }
      if (opcion == 'd'){
        client.execute("obdiv", noArgs, result);
      }
      if (opcion == 'p'){
        client.execute("obpot", noArgs, result);
      }
      if (opcion == 'r'){
        client.execute("obrad", noArgs, result);
      }
      if (opcion == 'h'){
        client.execute("obhist", emptyArgs, result);
      }
      
      std::cout << std::endl << "El resultado es: " << result << std::endl << std::endl << std::endl;
    }
  }
}